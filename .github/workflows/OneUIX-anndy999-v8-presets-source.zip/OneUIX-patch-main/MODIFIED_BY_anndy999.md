# OneUIX modified build by anndy999

This repository is a modified build of SoClear/OneUIX.
Original project attribution and the GNU AGPL v3 license are retained.

V8 test changes:
- Samsung status-bar two-line clock layout.
- Five user-selectable double-line size presets.
- Per-preset line spacing.
- Vertical centering plus a small optical upward correction.
- Single-line clock behavior remains compatible with the original scale slider.
