# V8 Samsung Fit Presets - build notes

Implemented in source code (not via an Actions-time patch):

- Two-line status-bar clock/date support.
- Five user-selectable double-line size presets.
- Per-preset line spacing.
- Full-height clock view + vertical centering.
- Small -0.65dp optical upward correction.
- Single-line clock returns to original OneUIX scaling behavior.
- Stable modified package id: `io.github.anndy999.oneuix`.
- Version: `1.7.0-anndy999-v8-presets` (`versionCode 20`).

Preset mapping:

| Preset | Time | Date | Line spacing |
| --- | ---: | ---: | ---: |
| Small | 76% | 64% | 0.72 |
| Compact | 80% | 68% | 0.69 |
| Standard | 84% | 72% | 0.66 |
| Large | 88% | 76% | 0.63 |
| Extra large | 92% | 80% | 0.60 |

Local build was attempted in the ChatGPT execution container but could not start because the
container cannot resolve `services.gradle.org` to download Gradle 9.6.1 and does not contain the
project's Android/JDK 25 toolchain cache. This is an environment/network limitation, not a Kotlin
compiler result. A real Android/Gradle environment still needs to run `./gradlew assembleDebug`.
